//
//  ViewController.swift
//  Closures
//
//  Created by Macbook on 15/01/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

import UIKit
import FirebaseFirestore

class ViewController: UIViewController {

    @IBOutlet weak var labelNombre: UILabel!
    let stringTexto = ""
    let misPreferencias = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()
        //misPreferencias.removeObject(forKey: "nombre")
//        misPreferencias.set("Hugo", forKey: "nombre")
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        var miNombre = misPreferencias.string(forKey: "nombre") ?? ""
        if miNombre == ""{
           preguntarNombre()
            miNombre = misPreferencias.string(forKey: "nombre") ?? ""
            
            print("Placeholder \(miNombre)")
        }else{
            let alertController = UIAlertController(title: "Yes te conozco", message: "Bienvenido \(miNombre)", preferredStyle: .alert)
            let confirmar = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alertController.addAction(confirmar)
            self.present(alertController, animated: true, completion: nil)
        }
        self.labelNombre?.text = miNombre
        let stringForJson = "https://raw.githubusercontent.com/MonCab/CursoIntermedioIntersemestral/master/examples.json"
        guard let url = URL(string: stringForJson) else {return}
        URLSession.shared.dataTask (with: url){(data, response, err) in
            guard let data = data else {return}
            
            /*let misDatos = String(data: data, encoding: .utf8)
            print(misDatos!)*/
            do{
                let miAlumno = try JSONDecoder().decode( [Alumno].self, from: data)
                print( miAlumno)
            } catch let error {
                print("Hubo error: \(error)")
            }
            
        }.resume()
        let alumnoParaEncodable = Alumno(id: 5, nombre: "Pancho", correo: "pancho@gmail.com", edad: 18)
        //try= Para decirle a la computadora que lo intente hacer(Para que no se interrumpa el programa)
        let alumnoEnJson = try! JSONEncoder().encode(alumnoParaEncodable)
        let alumnoJsonString = String(data:alumnoEnJson, encoding: .utf8)
        print(alumnoJsonString)
        //Esto es para firestore
        let archivos = Firestore.firestore()
        //sintaxis para recibir
        archivos.collection("alumno").getDocuments{
            (snapshot, error) in

            if error != nil{
                //manejar los errores  correctamente
                print("Hubo un error")
                } else {
                for document in (snapshot?.documents)!{
                    let jsonFB = try! JSONSerialization.data(withJSONObject: document.data())
                    do {
                        let alumnoDeFB = try JSONDecoder().decode(Alumno.self, from: jsonFB)
                        print(type(of: alumnoDeFB))
                        print(alumnoDeFB.nombre, alumnoDeFB.correo)
                    }catch let error {
                        print("error")
                    }
                }
            }
        }
        //Para subir datos a la base en formato json
        let montseUp = Alumno(id: 100, nombre: "Montse", correo: "mon@hmail.com", edad: 22)
        do {
            let montseJson = try JSONEncoder().encode(montseUp)
            let montseFS = try JSONSerialization.jsonObject(with: montseJson, options: [])
            archivos.collection("alumno").addDocument(data: montseFS as![String: Any] )
        }catch let error{
            print("Hubo error al subir")
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    func preguntarNombre(){
        let alertController = UIAlertController(title: "Presentate", message: "Escribe tu nombre", preferredStyle: .alert)
        let confirmar = UIAlertAction(title: "Agregar", style: .default, handler: {
            (_) in
            if let textField = alertController.textFields?.first, let miTexto = textField.text{
                self.misPreferencias.set(miTexto, forKey: "nombre")
            }
            
        })
        let cancelar = UIAlertAction(title: "Cancelar", style: .cancel ){(_) in }
            alertController.addTextField{
                (textField) in
                textField.placeholder = "Ingresas tu nombre"
            }
        alertController.addAction(confirmar)
        alertController.addAction(cancelar)
        self.present(alertController, animated: true, completion: nil)
     return
    }

}


