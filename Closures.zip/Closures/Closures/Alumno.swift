//
//  Alumno.swift
//  Closures
//
//  Created by 2020-2 on 16/01/20.
//  Copyright © 2020 Macbook. All rights reserved.
//

import Foundation

struct Alumno: Decodable,Encodable {
    var id: Int
    var nombre: String
    var correo: String
    var edad: Int
    
    enum CodingKeys: String, CodingKey {
        case id
        case nombre
        case correo
        case edad
    }
}
